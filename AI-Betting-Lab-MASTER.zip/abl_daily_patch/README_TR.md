# AI Betting Lab — MASTER geliştirme paketi (birikimli)

**Sürüm:** 2026-10-19 / Daily Automation v3 — **tek ZIP, birikimli değişiklik paketi**.

Bu ZIP önceki V1/V2 günlük izleme ve kalite modülleri ile yeni V3 günlük koordinasyon, yerel sonuç uzlaştırma bağlantısı, doğrulanmış ileri tahmin performansı, güvenlik kabul kapısı ve manuel GitHub Actions preview iş akışını birlikte içerir. **Mevcut GitHub projesinin tamamının kopyası değildir.** 19 Ekim `feature/expert-engines` dalının üstüne uygulanacak yeni/değişen dosyaları içerir. Mevcut repo kodlarını, dashboard tasarımını ve migrations'ı silmez.

## Birleştirme

1. Mevcut `feature/expert-engines` deposunu bilgisayarına indir.
2. ZIP içindeki `abl_daily_patch/` **klasörünün içeriğini** (klasörün kendisini değil) deponun köküne kopyala; aynı yolları koru.
3. Depo kökünde `python scripts/apply_daily_health_patch.py` komutunu çalıştır. Bu script mevcut `dashboard/daily.py` dosyasına iki rapor alanı ekler; farklı beklenmedik sürüm görürse güvenle durur.
4. `python -m unittest discover -s tests_dashboard -v` ile yeni testleri çalıştır.
5. Mevcut repo bağımlılıkları kuruluysa `python -m dashboard.automation_cli --database data/dashboard-live.sqlite` komutuyla **manuel yerel** çalıştır.
6. GitHub Actions workflow sadece manuel preview'dur, otomatik `cron` **etkin değildir**.

## Modüller

- `dashboard/daily_health.py`: v2 kaynak ve uzman kuyruğu sağlık durumları.
- `dashboard/daily_quality.py`: güncellik, tekrarlanan fixture, senaryo ve hakem statüleri.
- `dashboard/daily_orchestrator.py`: SQLite ile günlük çalışma kimliği, aynı güne ikinci çalışma engeli, kayıt ve durum özeti; doğrulanmamış işlemler için fail-closed.
- `dashboard/automation_cli.py`: mevcut günlük model motoru + izinli kaynak kuyruğu + mevcut `ResultScheduler` üzerinden **manuel** entegrasyon. Kendi kendine kanıtsız tahmin kilitlemez.
- `dashboard/daily_performance.py`: sadece doğrulanmış, önceden kilitli maç öncesi tahminlerin Brier, Log Loss, kalibrasyon, kapsama; ROI/CLV boş.
- `dashboard/security_acceptance.py`: hosted kabul kontrolleri; kendi beyanı bile cron açmaz.
- `.github/workflows/daily-research-preview.yml`: manuel, izin değişkenleri ve kalıcı DB varlığı kontrolü, no cron.
- `tests_dashboard/`: 28 bağımsız yerel test.
- `docs/DAILY_AUTOMATION_ACCEPTANCE_TR.md`: gerçek kullanım, sınırlar ve kabul koşulları.

## Doğrulama ve sınırlar

**28 yeni test başarılı** (bu birikimli paketin kendi testleri). Gerçek 19 Ekim GitHub çalışma ağacının tüm testleri, hosted Supabase JWT/RLS, izinli canlı veri erişimi ve Vercel yayını doğrulanmadı. Günlük otomatik çalıştırma **tamamlandı denemez**; üretim cron kapalı kalır. GitHub API yazma izni 403 olduğu için bu dosyalar henüz PR #1'e yüklenmedi.

İşlevler yalnızca mevcut `dashboard.daily.run` model/Red Team/hakem hesaplamalarına ve `ResultScheduler`'ın immutable outcome journal kontrollerine dayanır. Geçmiş model araştırması ile ileriye dönük kilitli tahmin sonuçları ayrı tutulur. Sanal/gerçek bahis yok.

## V4 güvenlik denetimi — 2026-10-19

- `dashboard/hosted_readiness.py`: yedi güvenlik kabulü için 7 günlük, hash ve bağımsız denetçi alanlı manifest kontrolü. Salt manifest **asla** cron açmaz.
- `tests_dashboard/test_hosted_readiness.py`: sekiz yeni negatif/pozitif test.
- `dashboard/automation_cli.py`: yalnızca `done` durumundaki günlük çalışma dashboard JSON'unu değiştirir; `partial` mevcut yayını korur.
- Bağlı Supabase projesinde public tablo bulunmadı (salt-okunur sorgu). AI Betting Lab hosted JWT/RLS doğrulanmış değildir; bu yüzden otomatik günlük cron **kapalı**. Kullanıcının zamanlayıcı onayı kaydedildi; güvenlik kapılarını geçersiz kılmaz.

## 19 Ekim 2026 — günlük zamanlayıcı paketi

`.github/workflows/daily-research-scheduled.yml` günlük 04:30 UTC tetikleyicisini **hazır olarak içerir**. Kodun GitHub'a gönderilmesi ve varsayılan dalda etkinleşmesi gerekir; bu ZIP tek başına GitHub Actions çalıştırmaz. İlk iş `dashboard.scheduled_gate` ile yalnızca salt-okunur güvenlik ön kontrolü yapar. Yedi kabul kanıtı, üç ayrı depo değişkeni ve yerel kalıcı kota/iş defteri yoksa araştırma işi çalışmaz; tanı raporu artifact olarak saklanır. Her iki job'da da kontrol vardır. `LAB_RESEARCH_ACCEPTED`, `LAB_DURABLE_QUOTA_VERIFIED`, `LAB_HOSTED_SECURITY_ACCEPTED` bayrakları tek başına kanıt sayılmaz.

**Gerçek altyapı sınırı:** GitHub Actions ephemeral runner üzerinde `data/dashboard-live.sqlite` normalde bulunmaz. Dolayısıyla bugünkü workflow, onay verilmiş olsa bile araştırma job'unu otomatik başlatamaz. Hosted kalıcı kuyruk/kota deposu ve JWT/RLS entegrasyonu tamamlanmadan `ready=true` olmamalıdır. Şu anda gerçek Supabase tablosu/RLS doğrulaması yapılmadı. Kullanıcıdan tekrar proje kurması istenmez. Bu paket migration uygulamaz ve para işlemi yapmaz.

Kontrol: `PYTHONPATH=. python -m unittest discover -s tests_dashboard -v`; yeni `test_scheduled_gate.py` güvenli engelleme ve yetkilendirme mantığını sınar. Testler gerçek Supabase erişimi kanıtı değildir.
